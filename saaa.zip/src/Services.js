// Services.js
import React from 'react';

const Services = () => {
  return (
    <section>
      <h2>Our Services</h2>
      <ul>
        <li>Haircuts</li>
        <li>Hair Coloring</li>
        <li>Extensions</li>
        <li>Styling</li>
      </ul>
    </section>
  );
};

export default Services;
